package persistence;

import org.json.JSONException;
import org.junit.jupiter.api.Test;

import model.Disease;
import model.Population;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class TestJsonReader {
    @Test
    void testNoFile() {
        JsonReader reader = new JsonReader("./data/nonexistent.json");
        assertThrows(IOException.class, () -> reader.readPop());
        assertThrows(IOException.class, () -> reader.readDis());
        assertThrows(IOException.class, () -> reader.readSim());
    }

    @Test
    void testInvalidFormat() {
        JsonReader reader = new JsonReader("./data/invalid0.json");
        assertThrows(JSONException.class, () -> reader.readPop());
        assertThrows(JSONException.class, () -> reader.readDis());
        assertThrows(JSONException.class, () -> reader.readSim());
    }

    @Test
    void testNoPop() {
        JsonReader reader = new JsonReader("./data/invalid1.json");
        assertThrows(Exception.class, () -> reader.readPop());
    }

    @Test
    void testNoDis() {
        JsonReader reader = new JsonReader("./data/invalid2.json");
        assertThrows(Exception.class, () -> reader.readDis());
    }

    @Test
    void testNoSim() {
        JsonReader reader = new JsonReader("./data/invalid3.json");
        assertThrows(Exception.class, () -> reader.readSim());
    }

    @Test
    void testRead() {
        JsonReader reader = new JsonReader("./data/dssTest.json");
        assertDoesNotThrow(() -> {
            Population pop = reader.readPop();
            Disease dis = reader.readDis();
            int[] sim = reader.readSim();

            assertEquals("air", dis.getTransmission());
            assertEquals(2.5, dis.getStrength());

            assertEquals(200, sim[0]);
            assertEquals(200, sim[1]);

            assertEquals(3, pop.getRow());
            assertEquals(0.7, pop.getPeopleFlat().get(2).infiltrationLevel());
            assertEquals(0, pop.getPeopleFlat().get(2).getHygeneLevel());
        });
    }
}
