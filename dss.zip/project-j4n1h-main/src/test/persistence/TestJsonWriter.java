package persistence;

import org.json.JSONArray;
import org.junit.jupiter.api.Test;

import model.Population;
import model.Rng;
import model.RngDefault;
import model.Disease;

import java.io.FileNotFoundException;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

// citing JsonSerializationDemo
public class TestJsonWriter {
    @Test
    void testNonExistentFile() {
        JsonWriter writer = new JsonWriter("./data/nonexistent.json");
        assertThrows(FileNotFoundException.class, () -> writer.init());
    }

    @Test
    void testWriteToFile() {
        assertDoesNotThrow(() -> {
            JsonWriter writer = new JsonWriter("./data/dssEmpty.json");
            Rng rng = new RngDefault();
            Population pop = new Population(10, rng);
            Disease dis = new Disease(2.5, 10, 0, "contact", rng);
            JSONArray sim = new JSONArray();
            sim.put(200);
            sim.put(400);
            sim.put(2);
            sim.put(20);
            writer.init();
            writer.append(dis);
            writer.append(sim);
            writer.append(pop);
            writer.finalWrite();
            writer.close();

            JsonReader reader = new JsonReader("./data/dssEmpty.json");
            Population rpop = reader.readPop();
            Disease rdis = reader.readDis();
            int[] rsim = reader.readSim();
            assertEquals(pop.getRow(), rpop.getRow());
            assertEquals(dis.getMinExposure(), rdis.getMinExposure());
            assertEquals(dis.getTransmission(), rdis.getTransmission());
            assertEquals(sim.get(0), rsim[0]);
            assertEquals(sim.get(1), rsim[1]);
            assertEquals(sim.get(2), rsim[2]);
        });
    }
}
