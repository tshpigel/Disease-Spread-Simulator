package model;

import org.junit.jupiter.api.Test;

public class TestRngDefault {
    @Test
    public void test() {
        Rng rng = new RngDefault();
        rng.next();
    }
}
