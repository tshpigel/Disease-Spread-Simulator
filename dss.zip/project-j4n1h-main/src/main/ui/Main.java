package ui;

import model.Disease;
import model.Population;
import model.Rng;
import model.RngDefault;

import ca.ubc.cs.ExcludeFromJacocoGeneratedReport;

@ExcludeFromJacocoGeneratedReport
public class Main {
    public static final String PATH = "./data/dss.json";

    public static void main(String[] args) throws Exception {
        Inputs inputs = new Inputs();
        Rng rng = new RngDefault();

        Population pop;
        Disease dis;
        int[] sim = new int[4];

        if (inputs.hasLoading()) {
            pop = inputs.getLoadedPop();
            dis = inputs.getLoadedDis();
            sim[0] = inputs.getLoadedSim()[0];
            sim[1] = inputs.getLoadedSim()[1];
            sim[2] = inputs.getLoadedSim()[2];
            sim[3] = inputs.getLoadedSim()[3];
        } else {
            pop = new Population(inputs.getPopSize(), rng);
            dis = new Disease(inputs.getDiseaseStrength(), (int) inputs.getMinExposure(), 
                0, inputs.getTransmission(), rng);
            sim[0] = inputs.getTickRate();
            sim[1] = inputs.getMaxTicks();
            sim[2] = inputs.getSimulationType();
            sim[3] = 0;
        }

        // ternary to preserve 25 line limit
        new ConsoleGUI(sim[2] == 1 ? "ansi" : "ascii", pop, dis, sim[0], sim[1], sim[3]);
    }
}