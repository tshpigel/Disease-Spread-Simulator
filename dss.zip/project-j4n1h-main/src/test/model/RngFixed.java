package model;

// implementation of Rng that represents fixed values to test
public class RngFixed implements Rng {
    private final double[] values;
    private int index = 0;

    // EFFECTS: constructs dummy random values
    public RngFixed(double... values) {
        this.values = values;
    }

    // EFFECTS: returns the next fixed value set by the constructor
    @Override
    public double next() {
        double value = values[index % values.length];
        index++;

        return value;
    }
}
