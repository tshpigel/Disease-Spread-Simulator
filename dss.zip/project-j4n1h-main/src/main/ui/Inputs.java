package ui;

import java.util.Scanner;
import ca.ubc.cs.ExcludeFromJacocoGeneratedReport;
import model.Disease;
import model.Population;
import persistence.JsonReader;

@ExcludeFromJacocoGeneratedReport
// calling the constructor sets up the user inputs for the simulation
public class Inputs {
    private int popSize;
    private double diseaseStrength;
    private int minExposure;
    private String transmission;
    private int tickRate;
    private int maxTicks;
    private int simulationType;

    private boolean loading = false;
    private Population loadedPop;
    private Disease loadedDis;
    private int[] loadedSim;

    private JsonReader reader = new JsonReader(Main.PATH);

    Scanner scanner = new Scanner(System.in);

    // EFFECTS: creates all the user defined variables
    public Inputs() {
        try {
            Population loadedPop = reader.readPop();
            Disease loadedDis = reader.readDis();
            int[] loadedSim = reader.readSim();

            int response = loadingQuestions();

            if (response == 1) {
                this.loadedPop = loadedPop;
                this.loadedDis = loadedDis;
                this.loadedSim = loadedSim;
                this.loading = true;
                return;
            }
        } catch (Exception e) {
            System.out.print("");
        }

        introduction();
        section1();
        section2();
        section3();
        outro();
    }

    public int getPopSize() {
        return this.popSize;
    }

    public double getDiseaseStrength() {
        return this.diseaseStrength;
    }

    public int getMinExposure() {
        return this.minExposure;
    }

    public String getTransmission() {
        return this.transmission;
    }

    public int getTickRate() {
        return this.tickRate;
    }

    public int getMaxTicks() {
        return this.maxTicks;
    }

    public int getSimulationType() {
        return this.simulationType;
    }

    public Population getLoadedPop() {
        return this.loadedPop;
    }

    public Disease getLoadedDis() {
        return this.loadedDis;
    }

    public int[] getLoadedSim() {
        return this.loadedSim;
    }

    public boolean hasLoading() {
        return this.loading;
    }

    // EFFECTS: asks if user wants to load or not
    //          returns their response
    public int loadingQuestions() {
        System.out.println("You have a saved state from a previous simulation, "
                + "do you want to load it [1] or run a fresh simulation [2]?");
        System.out.print("1 or 2: ");
        int response = scanner.nextInt();
        while (response != 1 && response != 2) {
            System.out.print("1 or 2: ");
            response = scanner.nextInt();
        }

        return response;
    }

    // EFFECTS: introduces the program
    public void introduction() {
        System.out.println("Welcome to the Disease Spread Simulator");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
        System.out.println("Here you can experiment with different values which" 
                + " determine how a disease would spread throughout a population");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }

    // MODIFIES: this
    // EFFECTS: asks the first round of inputs
    public void section1() {
        System.out.print("\nChoose a grid width for the population [10 - 250]"
                + " (larger widths may require you to minimize the terminal): ");
        this.popSize = scanner.nextInt();
        while (this.popSize < 10 || this.popSize > 250) {
            this.popSize = scanner.nextInt();
        }

        System.out.print("Choose a transmission type (either air, contact, ingestion, or blood): ");
        this.transmission = scanner.next();
        while (!(this.transmission.equals("air") 
                || this.transmission.equals("contact") 
                || this.transmission.equals("ingestion")
                || this.transmission.equals("blood"))) {
            this.transmission = scanner.next();
        }

        System.out.print("Choose a minimum exposure integer between [1 - 30]" 
                + " (low minimum exposure means high spread rate): ");
        this.minExposure = scanner.nextInt();
        while (this.minExposure < 1 || this.minExposure > 30) {
            this.minExposure = scanner.nextInt();
        }
    }

    // MODIFIES: this
    // EFFECTS: asks the second round of inputs
    public void section2() {
        System.out.print("Choose the disease strength [1.0 - 3.0]"
                + " (strength also affects spread rate): ");
        this.diseaseStrength = scanner.nextDouble();
        while (this.diseaseStrength < 1.0 || this.diseaseStrength > 3.0) {
            this.diseaseStrength = scanner.nextDouble();
        }

        System.out.print("Choose the tick rate of the simulation in milliseconds (no faster than 100ms): ");
        this.tickRate = scanner.nextInt();
        while (this.tickRate < 100) {
            this.tickRate = scanner.nextInt();
        }

        System.out.print("Choose the number of ticks (days) until the simulation stops "
                + "(max 3000 but 500 is high enough for most simulations): ");
        this.maxTicks = scanner.nextInt();
        while (this.maxTicks < 1 || this.maxTicks > 3000) {
            this.maxTicks = scanner.nextInt();
        }
    }

    // MODIFIES: this
    // EFFECTS: asks the third round of inputs
    public void section3() {
        System.out.println("Lastly, enter 1 for a colorized simulation or enter 2 for an ascii simulation "
                + "(ascii will run smoother with larger populations)");
        System.out.println("In the color simulation: white = healthy, red = infected, green = immune, removed = dead");
        System.out.println("In the ascii simulation: H = healthy, C = infected/contagious, + = immune, - = dead");
        System.out.print("1 or 2: ");
        this.simulationType = scanner.nextInt();
        while (this.simulationType != 1 && this.simulationType != 2) {
            this.simulationType = scanner.nextInt();
        }
    }

    // EFFECTS: finishes up the spiel
    public void outro() {
        System.out.println("Some simulations end very quickly due to a resistant population, " 
                + "but usually high strength and low min exposure will almost guarantee destruction");
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
        System.out.println("You can press Enter to pause the simulation, which allows you to save the current state");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
        System.out.println("The simulation will now begin in 3 seconds");
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }
}
