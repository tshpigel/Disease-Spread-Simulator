package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.lang.Math;

import org.json.JSONArray;
import org.json.JSONObject;
import persistence.Writable;

// represents a grid of Persons with randomized values
public class Population implements Writable {
    private ArrayList<ArrayList<Person>> people;
    private int rowCount;
    private Rng rng;

    // REQUIRES: size >= 10
    // EFFECTS: creates a 2x2 matrix of Persons with randomized values
    public Population(int size, Rng rng) {
        this.rowCount = size;
        this.rng = rng;

        this.people = new ArrayList<ArrayList<Person>>();
        int id = 1;
        for (int i = 0; i < size; i++) {
            ArrayList<Person> row = new ArrayList<Person>();
            for (int j = 0; j < size; j++) {
                Person p = new Person(id, size, Person.oneHundredCutoff(rand(10, 90)) * 1.3, 
                        Person.oneHundredCutoff(rand(20, 90) * 1.1), 
                        rand(1, 100), rng.next() < .05, false, rng.next() < .85, 
                        Person.oneHundredCutoff(rand(40, 80) * 1.2), 0.0, new HashSet<Person>(), rng);
                row.add(p);
                id++;
            }
            this.people.add(row);
        }

        createFriendGroups();
    }

    // REQUIRES: size >= 10
    // EFFECTS: sets up the population creation for data loading
    public Population(int size, Rng rng, boolean init) {
        this.rowCount = size;
        this.rng = rng;

        this.people = new ArrayList<ArrayList<Person>>();
    }

    public int getRow() {
        return this.rowCount;
    }

    public ArrayList<ArrayList<Person>> getPeople() {
        return this.people;
    }

    public void setPeople(ArrayList<ArrayList<Person>> people) {
        this.people = people;
    }

    public Rng getRng() {
        return this.rng;
    }

    // EFFECTS: returns a random double between the lower and upper bounds
    private double rand(int lower, int upper) {
        return rng.next() * (upper - lower) + lower;
    }


    // EFFECTS: returns a 1D ArrayList of all people
    public ArrayList<Person> getPeopleFlat() {
        ArrayList<Person> all = new ArrayList<Person>();
        for (ArrayList<Person> row : this.people) {
            all.addAll(row);
        }

        return all;
    }

    // REQUIRES: a and b are part of the same population
    // EFFECTS: returns the euclidean distance between any two people
    public double distance(Person a, Person b) {
        int indexA = a.getId() - 1;
        int indexB = b.getId() - 1;

        int rowA = indexA / this.rowCount;
        int rowB = indexB / this.rowCount;
        int colA = indexA % this.rowCount;
        int colB = indexB % this.rowCount;

        return Math.sqrt(Math.pow(rowA - rowB, 2) + Math.pow(colA - colB, 2));
    }
        
    // EFFECTS: creates friend groups with closer people having higher probability for friendship
    public void createFriendGroups() {
        ArrayList<Person> flatPop = getPeopleFlat();
        List<Person> shuffledFlatPop = new ArrayList<>(flatPop);
        Collections.shuffle(shuffledFlatPop, new Random(0));
        double maxRadius = Math.pow(this.rowCount, 1 / 5.0);
        for (Person first : shuffledFlatPop) {
            int friendCount = (int) Math.floor(rng.next() * 9.0) + 2;
            for (Person friend : flatPop) {
                if (first.getFriends().size() >= friendCount) {
                    break;
                } 
                double dist = distance(first, friend);
                if (first == friend || dist > maxRadius) {
                    continue;
                }
                
                double probability = 1.0 / Math.pow((dist + 1), 2.5) * first.socialAmount() / 50;
                if (rng.next() < probability) {
                    first.getFriends().add(friend);
                    friend.getFriends().add(first);
                }
            }
        }
    }

    @Override
    public JSONArray toJson() {
        JSONArray people = new JSONArray();
        for (Person p : this.getPeopleFlat()) {
            JSONObject person = new JSONObject();
            person.put(Integer.toString(p.getId()), p.toJson());
            people.put(person);
        }

        return people;
    }
}