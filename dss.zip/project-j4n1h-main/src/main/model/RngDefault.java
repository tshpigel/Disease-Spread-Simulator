package model;

// implementation of Rng that generates a random number
public class RngDefault implements Rng {
    // EFFECTS: returns a random value as normal
    @Override
    public double next() {
        return Math.random();
    }
}
