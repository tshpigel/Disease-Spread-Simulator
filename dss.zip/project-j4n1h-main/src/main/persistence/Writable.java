package persistence;

import org.json.JSONArray;

// add to classes that are readable and writable for JSON persistence
// citing JsonSerializationDemo
public interface Writable {
    // EFFECTS: returns this as JSON array
    JSONArray toJson();
}