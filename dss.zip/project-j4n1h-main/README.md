# Disease Spread Simulator (DSS)

### Purpose
The DSS is meant to display a prediction of infection through a population via live visualization. The program will start by asking the user to input necessary parameters that will determine the range of percent chance for the disease to spread and whether it survives in a given person long enough to kill them or not. As a user, you can choose the specific values that control the spread graph. The two main classes will be the *Person* class which will represent the state of one specific person (multiple Persons per simulation) and the *Disease* class which determines which Persons are affected and how more will be affected (one Disease per simulation).

### Demographic
This program is meant for anybody that wants to simulate how a disease would spread within a population, and is moreso for educational purposes. Additionally, anybody that wants to visualize this type of simulation for fun would be included in the target demographic.

### Motivations
This project is of interest to me because I like to create things that have a lot of variability and uncertainty where the final result is not fully predictable. This project would allow me to incorporate a lot of that variability as disease spread relies on many different factors which all can individually be implemented.

<br/>

## User Stories
- As a user, I want to be able to add individuals to an initial population
- As a user, I want to be able to pause and resume the simulation
- As a user, I want to be able to manually save the current simulation once it has been paused
- As a user, I want to be able to view statistics on the percentage of healthy, immune, infected, and dead people
- As a user, I want to be able to see a visual representation see which people are healthy, immune, infected, or dead with colors or symbols
- As a user, I want to be able to configure parameters that determine disease spread and individual susceptibility in order to explore different potential epidemics
- As a user, I want to be able to control the speed of the simulation to adjust how fast the disease spreads