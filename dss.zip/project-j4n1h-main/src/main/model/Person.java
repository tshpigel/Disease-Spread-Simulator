package model;

import java.util.ArrayList;
import java.util.Set;

import org.json.JSONArray;
import persistence.Writable;

// represents a person with different values relating to the disease (i.e. susceptibility, hygene, etc)
public class Person implements Writable {
    private int id; // unique identifier given to each person
    private int rowLength; // length of a population row that person is a part of

    private double susceptibility; // how susceptible they are to contracting diseases
    private double hygeneLevel; // how hygenic they are
    private double recoverability; // how easily they deal with the disease
    private boolean immunocompromised; // if they are immunocompromised or not
    private boolean exhibitsSymptoms; // if they are exhibiting symptoms of the disease
    private boolean vaccinated; // if they are vaccinated
    private double social; // how often they socialize with friends/neighbors
    private double infiltration; // how much the disease has infiltrated their body (0.0 is not infected, 1.0 is death)
    private boolean alive; // if they are alive
    private boolean immunity; // if they have immunity (disease was cured on its own)

    private Set<Person> friends; // list of friends (ID specifies where they are in the population map)

    private Rng rng; // custom random generation to allow 100% code coverage

    // relative weightings which influence infiltration, contagion, friends, and overall probabilities
    // negative means it fights against the disease (abbreviated with first three letters)
    public static final double SUS_WEIGHT = 1.5;
    public static final double HYG_WEIGHT = -.15; // public so Friend class can access
    private static final double REC_WEIGHT = -.2;
    private static final double IMM_WEIGHT = 1.7; // for when immunocompromised is true
    private static final double VAC_WEIGHT = 1.4; // for when vaccinated is false
    private static final double EXH_WEIGHT = 0.2; // for when exhibitsSymptoms is true
    public static final double SOC_WEIGHT = 1.4; // public so Friend class can access
    public static final double FRI_WEIGHT = 0.3; // public so Friend class can access

    // REQUIRES: id < population size, rowLength < sqrt(population size), all doubles between 0.0 and 100.0
    //           except infiltration, which should be in between 0.0 and 1.0
    // EFFECTS: creates a person with parameters that lead to determining the overall chance of survival
    public Person(int id, int rowLength, 
            double susceptibility, double hygeneLevel, double recoverability, 
            boolean immunocompromised, boolean exhibitsSymptoms, boolean vaccinated,
            double social, double infiltration, Set<Person> friends, Rng rng) {
        this.id = id;
        this.rowLength = rowLength;
        this.susceptibility = susceptibility;
        this.hygeneLevel = hygeneLevel;
        this.recoverability = recoverability;
        this.immunocompromised = immunocompromised;
        this.exhibitsSymptoms = exhibitsSymptoms;
        this.vaccinated = vaccinated;
        this.social = social;
        this.infiltration = infiltration;
        this.friends = friends;
        this.rng = rng;

        this.alive = true;
        this.immunity = false;
    }

    public int getId() {
        return this.id;
    }

    public int getRowLength() {
        return this.rowLength;
    }

    public double getSusceptibility() {
        return this.susceptibility;
    }

    public double getHygeneLevel() {
        return this.hygeneLevel;
    }

    public void setHygene(double d) {
        this.hygeneLevel = d;
    }

    public double getRecoverability() {
        return this.recoverability;
    }

    public boolean isImmunocompromised() {
        return this.immunocompromised;
    }

    public boolean doesExhibitSymptoms() {
        return this.exhibitsSymptoms;
    }

    public boolean isVaccinated() {
        return this.vaccinated;
    }

    public double socialAmount() {
        return this.social;
    }

    public double infiltrationLevel() {
        return this.infiltration;
    }

    public Set<Person> getFriends() {
        return this.friends;
    }

    public Rng getRng() {
        return this.rng;
    }

    public boolean isAlive() {
        return this.alive;
    }

    public boolean isImmune() {
        return this.immunity;
    }


    
    // EFFECTS: returns 0.0 if d is negative
    public static double zeroCutoff(double d) {
        if (d < 0) {
            d = 0;
        }
        return d;
    }

    // EFFECTS: return 100.0 if d is greater than 100
    public static double oneHundredCutoff(double d) {
        if (d > 100) {
            d = 100;
        }
        return d;
    }

    // EFFECTS: returns a random double between the lower and upper bounds
    public double rand(int lower, int upper) {
        return rng.next() * (upper - lower) + lower;
    }


    // EFFECTS: returns a double between 0.0 and 100.0 representing how contagious this person is
    public double contagion() {
        double soc = this.social; // initial social multiplier
        double hyg = this.hygeneLevel; // initial hygene multiplier
        if (this.exhibitsSymptoms) {
            soc *= SOC_WEIGHT;
            hyg += rand(5, 15);
            return zeroCutoff(oneHundredCutoff((soc * SOC_WEIGHT + hyg * HYG_WEIGHT) * this.infiltration));
        } else {
            return 0.0;
        }
    }

    // REQUIRES: friends != null
    // EFFECTS: returns a double between 0.0 and 100.0 representing how much friends could affect infiltration
    public double friendFactor() {
        double total = 0.0;
        for (Person f : this.friends) {
            total += f.contagion() * FRI_WEIGHT;
        }
        
        return total;
    }

    // REQUIRES: baseInfiltration < 0.1
    // MODIFIES: this
    // EFFECTS: infects the person with an initial dosage of the disease/strain
    public void getInfected(double baseInfiltration) {
        this.infiltration = baseInfiltration;
    }

    // REQUIRES: this.infiltration went back to 0
    // MODIFIES: this
    // EFFECTS: person gains immunity as a result of fighting off the disease on their own
    public void gainImmunity() {
        this.immunity = true;
        this.infiltration = 0.0;
        this.recoverability = 100.0;
    }

    // REQUIRES: this.infiltration > 0.0
    // MODIFIES: this
    // EFFECTS: helper for tick(), updates infiltration for an infected Person
    public void infectedTick(Disease d) {
        double ifNotVaxxed = 0.0;
        double ifImmunoComp = 0.0;
        if (!this.vaccinated) {
            ifNotVaxxed = rng.next() * this.infiltration * VAC_WEIGHT;
        }
        if (this.immunocompromised) {
            ifImmunoComp = rng.next() * this.infiltration * IMM_WEIGHT;
        }
        if (!this.exhibitsSymptoms && d.incubationLeft(this) <= 0.0) {
            this.exhibitsSymptoms = true;
        } 

        this.infiltration += rng.next()
                * (this.hygeneLevel * HYG_WEIGHT + this.recoverability * REC_WEIGHT
                + d.getStrength() * Disease.WEIGHT + ifImmunoComp + ifNotVaxxed) / 10.0;
        
        if (this.recoverability > 0.0) {
            this.recoverability -= 0.03;
        }
        this.infiltration = zeroCutoff(this.infiltration);
    }

    // REQUIRES: this.infiltration == 0.0
    // MODIFIES: this
    // EFFECTS: helper for tick(), updates spreadOrder for all potential infections
    public Person[] healthyTick(Disease d) {
        Person[] spreadOrder = new Person[2];
        if (rng.next() < this.social / 100) {
            for (Person friend : this.friends) {
                if (friendFactor() > 0
                        && ((friend.doesExhibitSymptoms() && rng.next() < friend.social / 50 * EXH_WEIGHT) 
                        || (!friend.doesExhibitSymptoms() && rng.next() < friend.social / 50))) {
                    spreadOrder[0] = friend;
                    spreadOrder[1] = this;
                }
            }
        }
        return spreadOrder;
    }

    // MODIFIES: this
    // EFFECTS: updates infiltration level based on both random probability and contagion() of surrounding people
    public Person[] tick(Disease d) {
        if (!this.immunity && this.alive) {
            if (this.infiltration > 0.0) { // is infected and not immune
                infectedTick(d);
                if (this.infiltration <= 0.0) {
                    this.gainImmunity();
                } else if (this.infiltration >= 100.0) {
                    this.alive = false;
                }
            } else { // is not infected
                return healthyTick(d);
            }
        }
        return null;
    }

    @Override
    public JSONArray toJson() {
        JSONArray json = new JSONArray();
        json.put(susceptibility);
        json.put(hygeneLevel);
        json.put(recoverability);
        json.put(immunocompromised);
        json.put(exhibitsSymptoms);
        json.put(vaccinated);
        json.put(social);
        json.put(infiltration);
        ArrayList<Integer> ids = new ArrayList<Integer>();
        for (Person p : this.friends) {
            ids.add(p.id);
        }
        json.put(ids);

        return json;
    }
}