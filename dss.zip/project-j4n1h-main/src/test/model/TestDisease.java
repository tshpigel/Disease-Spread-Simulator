package model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;
import java.util.HashSet;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestDisease {
    Disease weak;
    Disease strong;
    Disease cdis;
    Disease bdis;
    Disease idis;
    Person greg;
    Person koivunen;
    Rng rng = new RngFixed(0.0, 1.0);

    @BeforeEach
    void runBefore() {
        weak = new Disease(1.0, 30, 0.4, "air", rng);
        strong = new Disease(3.0, 1, 0.4, "air", rng);
        cdis = new Disease(2.0, 20, 0.4, "contact", rng);
        bdis = new Disease(2.0, 20, 0.4, "blood", rng);
        idis = new Disease(2.0, 20, 0.4, "ingestion", rng);

        Set<Person> koivGroup = new HashSet<Person>();
        Set<Person> gregGroup = new HashSet<Person>();
        greg = new Person(1, 5, 20, 30, 40, false, false, true, 70, 0.3, koivGroup, rng);
        koivunen = new Person(2, 5, 50, 90, 25, true, false, true, 60, 0.0, gregGroup, rng);
        koivGroup.add(koivunen);
        gregGroup.add(greg);
    }

    @Test
    void testConstructor() {
        assertEquals(1.0, weak.getStrength());
        assertEquals(30, weak.getMinExposure());
        assertEquals(0.4, weak.getMutationProbability());
        assertEquals("air", weak.getTransmission());
        assertEquals(rng, weak.getRng());
    }

    @Test
    void testIncubationPeriod() {
        double incubationGreg = weak.incubationLeft(greg);
        assertEquals(-0.3, incubationGreg);
    }

    @Test
    void testTransmissionProbability() {
        assertEquals(0.35, weak.transmissionProbability());
        assertEquals(0.25, cdis.transmissionProbability());
        assertEquals(0.15, idis.transmissionProbability());
        assertEquals(0.05, bdis.transmissionProbability());
    }

    @Test
    void testSpread() {
        assertEquals(0.0, koivunen.infiltrationLevel());
        assertEquals(0.3, greg.infiltrationLevel());
        weak.spread(greg, koivunen);
        assertEquals(0.0, koivunen.infiltrationLevel(), 1e-6);
        strong.spread(greg, koivunen);
        assertEquals(0.05, koivunen.infiltrationLevel(), 1e-6);
    }
}
