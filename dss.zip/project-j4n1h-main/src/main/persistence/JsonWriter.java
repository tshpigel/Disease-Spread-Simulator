package persistence;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import org.json.JSONArray;
import org.json.JSONObject;

import model.Population;
import model.Disease;

// represents a JSON writer that will add the data to the json files
// citing JsonSerializationDemo
public class JsonWriter {
    private static final int TAB = 4;
    private PrintWriter writer;
    private String destination;

    // private String toWrite = "{\n\t";
    private JSONObject toWrite;

    // EFFECTS: constructs a writer with a given file destination
    public JsonWriter(String destination) {
        this.destination = destination;
        toWrite = new JSONObject();
    }

    // MODIFIES: this
    // EFFECTS: initializes the PrintWriter at the destination but
    //          throws a FileNotFoundException if destination doesn't exist
    public void init() throws FileNotFoundException {
        File dest = new File(this.destination);

        if (!dest.exists()) {
            throw new FileNotFoundException("File does not exist");
        }

        this.writer = new PrintWriter(dest);
    }

    // MODIFIES: this
    // EFFECTS: appends a disease to the json
    public void append(Disease dis) {
        toWrite.put("disease", dis.toJson());
    }

    // MODIFIES: this
    // EFFECTS: appends the simulation setup to the json
    public void append(JSONArray sim) {
        toWrite.put("simsetup", sim);
    }

    // MODIFIES: this
    // EFFECTS: appends a population to the json
    public void append(Population pop) {
        // JSONArray jsonPop = pop.toJson();
        toWrite.put("population", pop.toJson());
    }

    // EFFECTS: writes the final string to the json
    public void finalWrite() {
        writer.print(toWrite.toString(TAB));
    }

    // MODIFIES: this
    // EFFECTS: closes the writer
    public void close() {
        writer.close();
    }
}
