package model;

import org.json.JSONArray;
import persistence.Writable;

// represents a disease that can transmit from an infected person to a healthy person
public class Disease implements Writable {
    private double strength;
    private double minExposure;
    private double mutationProbability;
    private String transmission;

    private Rng rng;

    // transmission type probabilities
    private static final double AIR = 0.35;
    private static final double CONTACT = 0.25;
    private static final double INGESTION = 0.15;
    private static final double BLOOD = 0.05;

    public static final double WEIGHT = 12.0;

    // REQUIRES: strength is between 1.0 and 10.0
//               minExposure is between 1.0 and 100.0
    //           transmission is one of "air", "contact", "ingestion", "blood"
    //           mutationProbability is between 0.0 and 1.0
    // EFFECTS: creates the base features of a disease
    public Disease(double strength, double minExposure, double mutationProbability, String transmission, Rng rng) {
        this.strength = strength;
        this.minExposure = minExposure;
        this.mutationProbability = mutationProbability;
        this.transmission = transmission;
        this.rng = rng;
    }

    public double getStrength() {
        return this.strength;
    }

    public double getMinExposure() {
        return this.minExposure;
    }

    public double getMutationProbability() {
        return this.mutationProbability;
    }

    public String getTransmission() {
        return this.transmission;
    }

    public Rng getRng() {
        return this.rng;
    }

    // EFFECTS: returns a random double between the lower and upper bounds
    private double rand(int lower, int upper) {
        return rng.next() * (upper - lower) + lower;
    }

    // EFFECTS: returns transmission probability
    public double transmissionProbability() {
        if (this.transmission.equals("air")) {
            return AIR;
        } else if (this.transmission.equals("contact")) {
            return CONTACT;
        } else if (this.transmission.equals("ingestion")) {
            return INGESTION;
        } else {
            return BLOOD;
        }
    }

    // REQUIRES: p.infiltrationLevel() > 0 && !p.doesExhibitSymptoms()
    // EFFECTS: returns a random time (in ticks/days) until symptoms show for the person
    //          a negative/zero output means incubation will be over
    public double incubationLeft(Person p) {
        return rand(0, 25) / 100.0 - p.infiltrationLevel();
    }

    // REQUIRES: healthy does not have the disease (healthy.infiltrationLevel() == 0.0)
    // MODIFIES: infected
    // EFFECTS: attempts to spread the disease if minExposure is reached
    public void spread(Person infected, Person healthy) {
        if (infected.getHygeneLevel() * Person.HYG_WEIGHT
                + healthy.getSusceptibility() * Person.SUS_WEIGHT 
                + healthy.friendFactor() * Person.FRI_WEIGHT
                > this.minExposure / transmissionProbability()) {
            healthy.getInfected(rand(5, 15) / 100);
        }
    }

    @Override
    public JSONArray toJson() {
        JSONArray json = new JSONArray();
        json.put(strength);
        json.put(minExposure);
        json.put(mutationProbability);
        json.put(transmission);

        return json;
    }
}