package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestPopulation {
    Population pop;
    Rng rng;
    Person first;
    Person middle;
    Person last;

    @BeforeEach
    void runBefore() {
        rng = new RngFixed(0.0, 0.0, 0.0, 0.0, 0.9);
        pop = new Population(10, rng);
        first = pop.getPeople().get(0).get(0);
        middle = pop.getPeople().get(2).get(2);
        last = pop.getPeople().get(4).get(4);
    }

    @Test
    void testConstructor() {
        assertEquals(10, pop.getPeople().size());
        assertEquals(0.0, last.infiltrationLevel());
        assertEquals(10, pop.getRow());
        assertEquals(rng, pop.getRng());
    }

    @Test
    void testFlatPeople() {
        assertEquals(100, pop.getPeopleFlat().size());
    }

    @Test
    void testDistance() {
        assertEquals(Math.sqrt(32), pop.distance(first, last));
        assertEquals(Math.sqrt(8), pop.distance(first, middle));
        assertEquals(Math.sqrt(8), pop.distance(middle, last));
    }

    @Test
    void testFriendGroupCreation() {
        int s1 = first.getFriends().size();
        int s2 = middle.getFriends().size();
        int s3 = last.getFriends().size();
        int sum1 = s1 + s2 + s3;
        pop.createFriendGroups();
        int s4 = first.getFriends().size();
        int s5 = middle.getFriends().size();
        int s6 = last.getFriends().size();
        int sum2 = s4 + s5 + s6;
        assertTrue(sum2 > sum1);
    }
}