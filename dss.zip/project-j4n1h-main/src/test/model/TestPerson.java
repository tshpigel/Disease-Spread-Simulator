package model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestPerson {
    Person john; // no friends, very clean
    Person bob; // only one of the friend group to not be infected yet
    Person frank; // has the disease but doesn't exhibit symptoms
    Person hryckowian; // thinks he has friends, very unhygenic, has the disease
    Person sam; // very social, got the disease from hryckowian
    Person fiskerMolgaard; // going to heal
    Person ristolainen; // too lazy to add more comments for people
    Person blueger; // canucks player
    Person vaakanainen; // former bruin

    Set<Person> friends0 = new HashSet<Person>();
    Set<Person> friends1 = new HashSet<Person>();
    Set<Person> friends2 = new HashSet<Person>();
    Set<Person> friends3 = new HashSet<Person>();
    Set<Person> friends4 = new HashSet<Person>();
    Set<Person> friends5 = new HashSet<Person>();

    Disease disease;
    Rng rng = new RngFixed(0.0, 0.5, 0.1, 0.99, 0.9);

    @BeforeEach
    void runBefore() {
        john = new Person(1, 50, 30, 100, 70, false, false, true, 20, 0.0, friends0, rng);
        bob = new Person(2, 50, 90, 30, 90, false, false, true, 40, 0.0, friends2, rng);
        frank = new Person(3, 50, 40, 80, 10, false, false, true, 40, 20.0, friends3, rng);
        hryckowian = new Person(4, 50, 70, 20, 30, true, true, false, 60, 65.0, friends1, rng);
        sam = new Person(5, 50, 30, 80, 50, false, true, false, 80, 40.0, friends1, rng);
        fiskerMolgaard = new Person(6, 50, 70, 20, 0, false, true, true, 20, 1.0, friends4, rng);
        ristolainen = new Person(7, 50, 30, 80, 100, false, false, true, 10, 0.1, friends0, rng);
        blueger = new Person(8, 50, 30, 80, 100, false, false, true, 10, 0.0, friends1, rng);
        vaakanainen = new Person(99, 50, 50, 50, 50, false, false, true, 100, 0.0, friends1, rng);

        friends1.addAll(Arrays.asList(bob, frank));
        friends2.addAll(Arrays.asList(frank, sam));
        friends3.addAll(Arrays.asList(bob, sam));
        friends4.addAll(Arrays.asList(ristolainen, sam, hryckowian));
        friends5.addAll(Arrays.asList(blueger, ristolainen));
        
        disease = new Disease(2.0, 10, 2, "contact", rng);
    }

    @Test
    void testConstructor() {
        ArrayList<Person> friendsTest = new ArrayList<Person>();
        friendsTest.add(frank);
        friendsTest.add(sam);
        ArrayList<Person> bobFriendList = new ArrayList<Person>(bob.getFriends());

        assertEquals(2, bob.getId());
        assertEquals(50, bob.getRowLength());
        assertEquals(90, bob.getSusceptibility(), 1e-6);
        assertEquals(30, bob.getHygeneLevel(), 1e-6);
        assertEquals(90, bob.getRecoverability(), 1e-6);
        assertFalse(bob.isImmunocompromised());
        assertFalse(bob.doesExhibitSymptoms());
        assertTrue(bob.isVaccinated());
        assertEquals(40, bob.socialAmount(), 1e-6);
        assertEquals(0.0, bob.infiltrationLevel(), 1e-6);
        assertTrue(bob.isAlive());
        assertEquals(rng, bob.getRng());

        assertTrue(bobFriendList.contains(friendsTest.get(0)));
        assertTrue(bobFriendList.contains(friendsTest.get(1)));
    }

    @Test
    void testSetHygene() {
        assertEquals(80, frank.getHygeneLevel(), 1e-6);
        frank.setHygene(82);
        assertEquals(82, frank.getHygeneLevel(), 1e-6);
    }

    @Test
    void testCutoffs() {
        assertEquals(20, Person.zeroCutoff(20), 1e-6);
        assertEquals(20, Person.oneHundredCutoff(20), 1e-6);
        assertEquals(0, Person.zeroCutoff(-30), 1e-6);
        assertEquals(100, Person.oneHundredCutoff(104), 1e-6);
    }

    @Test
    void testRand() {
        double r = bob.rand(1, 10);
        assertEquals(1.0, r);
    }

    @Test
    void testContagion() {
        double frankContagionLevel = frank.contagion();
        assertEquals(frankContagionLevel, 0.0, 1e-6);
        double hryckowianContagionLevel = hryckowian.contagion();
        assertEquals(100.0, hryckowianContagionLevel, 1e-6);
    }

    @Test
    void testFriendFactor() {
        double bobFriendFactor = bob.friendFactor();
        assertEquals(30.0, bobFriendFactor);
    }

    @Test
    void testGetInfected() {
        assertEquals(john.infiltrationLevel(), 0.0, 1e-6);
        john.getInfected(2);
        assertEquals(john.infiltrationLevel(), 2.0, 1e-6);
    }

    @Test
    void testGainImmunity() {
        assertFalse(frank.isImmune());
        frank.gainImmunity();
        assertTrue(frank.isImmune());
    }

    @Test
    void testImmuneOrDeadTick() {
        frank.tick(disease);
        frank.gainImmunity();
        assertNull(frank.tick(disease));
        for (int i = 0; i < 7; i++) {
            hryckowian.tick(disease);
        }
        assertFalse(hryckowian.isAlive());
    }

    @Test
    void testHealthyTick() {
        assertNull(john.tick(disease)[0]);
        bob.tick(disease);
        bob.tick(disease);
        rng = new RngFixed(0.1, 0.99, 0.99, 0.99);
        runBefore();
        bob.tick(disease);
        vaakanainen.tick(disease);
        vaakanainen.tick(disease);
        blueger.tick(disease);
        blueger.tick(disease);
        bob.tick(disease);
        assertNull(john.tick(disease)[0]);
    }

    @Test
    void testNoMoreIncubation() {
        assertFalse(frank.doesExhibitSymptoms());
        frank.tick(disease);
        assertTrue(frank.doesExhibitSymptoms());
        assertEquals(0.1, ristolainen.infiltrationLevel(), 1e-6);
        ristolainen.tick(disease);
        assertEquals(0.0, ristolainen.infiltrationLevel(), 1e-6);
        fiskerMolgaard.tick(disease);
        assertFalse(blueger.doesExhibitSymptoms());
        blueger.tick(disease);
        assertFalse(blueger.doesExhibitSymptoms());
    }
}