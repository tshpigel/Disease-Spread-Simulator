package model;

// rng template so different random functions can be used in simulation vs in testing
public interface Rng {
    // EFFECTS: returns a double between 0.0 and 1.0
    double next();
}
