package ui;

import model.Person;
import model.Population;
import persistence.JsonWriter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;

import ca.ubc.cs.ExcludeFromJacocoGeneratedReport;

import model.Disease;

// represents the console interface
@ExcludeFromJacocoGeneratedReport
public class ConsoleGUI {
    private double infectedPercentage;
    private double healthyPercentage;
    private double deadPercentage;
    private double immunePercentage;

    private int populationSize;
    private int daysPassed;
    private int lastSaved;

    private Population pop;
    private Disease disease;

    private int rate;
    private int maxTicks;
    private int mode;

    // ANSI codes for colorized console output
    private static final String INFECTED = "\u001B[31;1m";
    public static final String HEALTHY = "\u001B[37m";
    private static final String DEAD = "\u001B[35;1m";
    private static final String IMMUNE = "\u001B[32m";

    private static final String SAVED = "\u001B[32m";

    private static final String ANSI_RESET = "\u001B[0m";

    // volatile instead of normal in order to work between threads
    private volatile boolean running = true;
    private volatile boolean await = false;

    private final Object pause = new Object();

    private final Scanner scanner = new Scanner(System.in);

    private JsonWriter writer = new JsonWriter(Main.PATH);
    
    // EFFECTS: starts a simulation given the printing mode, initial batch of people, and disease
    public ConsoleGUI(String mode, Population pop, Disease disease, int rate, int maxTicks, int last) throws Exception {
        this.pop = pop;
        this.disease = disease;
        this.rate = rate;
        this.maxTicks = maxTicks;
        this.lastSaved = last;
        // ternary to preserve 25 line limit
        this.mode = mode.equals("ansi") ? 1 : 2;

        initialize();

        Thread thread = checkState();
        thread.setDaemon(true);
        thread.start();

        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
        Runnable update = new Runnable() {
            @ExcludeFromJacocoGeneratedReport
            @Override
            public void run() {
                mainTick(mode, executor);
            }
        };

        executor.scheduleAtFixedRate(update, 0, rate, TimeUnit.MILLISECONDS);
    }

    public double getInfectedPercentage() {
        return this.infectedPercentage;
    }

    public double getImmunePercentage() {
        return this.immunePercentage;
    }

    public double getHealthyPercentage() {
        return this.healthyPercentage;
    }

    public double getDeadPercentage() {
        return this.deadPercentage;
    }
    

    // EFFECTS: returns the center Person of pop or any of the 4 centers if pop.getRowLength() is even
    //          the center Person will be the starting point for the disease simulation
    public void patientZero(Population pop) {
        ArrayList<Person> flat = pop.getPeopleFlat();
        int size = flat.size();
        int rootSize = pop.getPeople().size();
        int middle = (int) Math.floor(size / 2);
        Person center;
        if (size % 2 == 0) {
            int[] options = {rootSize / 2, -rootSize / 2, rootSize / 2 - 1, -rootSize / 2 - 1};
            int option = options[(int) Math.floor(Math.random() * options.length)];
            center = flat.get(middle + option);
        } else {
            center = flat.get(middle);
        }

        center.getInfected(0.2);

        // to prevent the possiblity of the simulation immediately ending (center becomes immune)
        center.setHygene(0.0);
        center.getFriends().forEach(friend -> friend.setHygene(0.0));
    }

    // EFFECTS: runs a full population tick of the simulation with ansi colorization
    public void printTemplate(String[] array) {
        ArrayList<Person[]> spreads = new ArrayList<Person[]>();
        double[] idch = new double[]{0.0, 0.0, 0.0, 0.0}; // immune dead contagious healthy
        for (ArrayList<Person> alp : pop.getPeople()) {
            for (Person p : alp) {
                spreads.add(p.tick(disease));
                if (p.isImmune()) {
                    idch[0] += 1.0;
                    System.out.print(array[0]);
                } else if (!p.isAlive()) {
                    idch[1] += 1.0;
                    System.out.print(array[1]);
                } else if (p.infiltrationLevel() > 0.0) {
                    idch[2] += 1.0;
                    System.out.print(array[2]);
                } else {
                    idch[3] += 1.0;
                    System.out.print(array[3]);
                }

            }
            System.out.print("\n");
        }

        updateStatsAndSpread(spreads, disease, idch);
    }

    // EFFECTS: completes functionality for printTemplate
    public void updateStatsAndSpread(ArrayList<Person[]> spreads, Disease disease, double[] idch) {
        this.immunePercentage = idch[0] / populationSize;
        this.deadPercentage = idch[1] / populationSize;
        this.infectedPercentage = idch[2] / populationSize;
        this.healthyPercentage = idch[3] / populationSize;

        for (Person[] spread : spreads) {
            if (spread != null && spread[0] != null && spread[1] != null) {
                disease.spread(spread[0], spread[1]);
            }
        }
    }

    // REQUIRES: mode.equals("ansi")
    // EFFECTS: runs a full population tick of the simulation with ansi colorization
    public void printAnsi(Population pop, Disease disease) {
        printTemplate(
            new String[]{
                IMMUNE + "● " + ANSI_RESET,
                "  ",
                INFECTED + "● " + ANSI_RESET,
                HEALTHY + "● " + ANSI_RESET
            });
    }

    // REQUIRES: mode.equals("ascii")
    // EFFECTS: runs a full population tick of the simulation with ascii characters and minimal colorization
    public void printAscii(Population pop, Disease disease) {
        printTemplate(new String[]{"+ ", "- ", "C ", "H "});
    }

    // EFFECTS: returns the relevant live statistics on the disease as a string
    public String getStats() {
        String toReturn = "\n";
        toReturn += "Healthy Population: " + getHealthyPercentage() * 100 + "%\n";
        toReturn += "Infected Population: " + getInfectedPercentage() * 100 + "%\n";
        toReturn += "Immune Population: " + getImmunePercentage() * 100 + "%\n";
        toReturn += "Dead Population: " + getDeadPercentage() * 100 + "%\n";
        toReturn += "Days passed: " + this.daysPassed + SAVED 
                + " (Last saved on Day " + lastSaved + ")\n" + ANSI_RESET;
        
        return toReturn;
    }

    // EFFECTS: initializes values and returns OS type
    public void initialize() {
        if (lastSaved == 0) {
            patientZero(pop);
        }
        this.populationSize = pop.getPeopleFlat().size();
        this.infectedPercentage = 1.0 / populationSize;
        this.healthyPercentage = 1.0 - this.infectedPercentage;
        this.deadPercentage = 0.0;
        this.immunePercentage = 0.0;
        this.daysPassed = lastSaved;
    }

    // EFFECTS: prints all the end data
    public void end(Disease disease) {
        System.out.println("Simulation complete!\n\n");


        System.out.println("Configuration:");
        System.out.println("Population size: " + populationSize);
        System.out.println("Disease strength: " + (disease.getStrength()));
        System.out.println("Minimum exposure: " + disease.getMinExposure());
        System.out.println("Method of transmission: " + disease.getTransmission() + "\n");

        System.out.println("Number of people unaffected: " + (int) (healthyPercentage * populationSize));
        System.out.println("Number of people infected: " + (int) (infectedPercentage * populationSize));
        System.out.println("Number of people immune: " + (int) (immunePercentage * populationSize));
        System.out.println("Number of people dead: " + (int) (deadPercentage * populationSize));
    }

    // REQUIRES: mode is either "ansi" or "ascii"
    // EFFECTS: prints the grid based on the mode
    public void mainPrint(String mode) {
        if (mode.equals("ansi")) {
            printAnsi(pop, disease);
        } else {
            printAscii(pop, disease);
        }
        System.out.print(getStats());
    }

    public void resetJson() {
        try {
            writer.init();
            writer.finalWrite(); // reset the json file
            writer.close();
        } catch (IOException e) {
            System.out.println("Could not clear JSON");
        }
    }

    // EFFECTS: runs the main thread 
    public void mainTick(String mode, ScheduledExecutorService executor) {
        if (await) {
            return;
        }

        // synchronized required for guaranteeing full clear when pausing because of multithread
        synchronized (pause) {
            if (await) {
                return;
            }
            daysPassed++;
            // clears terminal
            System.out.print("\033\143");
            System.out.flush();

            mainPrint(mode);

            if (!running) {
                executor.shutdownNow();
                end(disease);
            } else if (daysPassed >= maxTicks || infectedPercentage == 0.0) {
                running = false;
                executor.shutdown();
                end(disease);
                resetJson();
            }
        }
    }

    // EFFECTS: prints the pause screen
    public void pausePrint(String choice) throws IOException {
        if (choice.equals("s")) {
            try {
                lastSaved = daysPassed;
                JSONArray sim = new JSONArray();
                sim.put(rate);
                sim.put(maxTicks);
                sim.put(mode);
                sim.put(lastSaved);
                writer.init();
                writer.append(disease);
                writer.append(sim);
                writer.append(pop);
                writer.finalWrite();
                writer.close();
            } catch (IOException e) {
                System.out.print("Could not save");
                running = false;
            }
        } else if (choice.equals("q")) {
            running = false;
        } 
        await = false;
    }

    public void ifPressedEnter(String line) throws IOException {
        if (line.isEmpty() || !line.isEmpty()) {
            synchronized (pause) {
                await = true;

                System.out.print("\033\143");
                System.out.flush();

                System.out.println("You have paused the simulation.");
                System.out.println("Do you want to save the current state [s], quit [q], or continue [c]?");
                System.out.print("Enter the letter associated with the square brackets: ");
            }

            try {
                line = scanner.nextLine();
                while (!line.equals("s") && !line.equals("q") && !line.equals("c")) {
                    System.out.print("[s], [q], or [c]: ");
                    line = scanner.nextLine();
                }
                pausePrint(line);
            } catch (IOException e) {
                System.err.print(e);
                running = false;
            }
        }
    }

    // EFFECTS: returns the alternate thread used to check for simulation pausing
    //          will end the program if something goes wrong
    public Thread checkState() throws Exception {
        return new Thread(() -> {
            try {
                while (running) {
                    if (!scanner.hasNextLine()) {
                        break;
                    }

                    String line = scanner.nextLine();

                    if (!await) { // 'if pressed enter'
                        try {
                            ifPressedEnter(line);
                        } catch (IOException e) {
                            System.err.print(e);
                            running = false;
                        }
                        continue;
                    } 
                }
            } catch (IllegalStateException | NoSuchElementException e) {
                System.out.print("");
            } finally {
                scanner.close();
            }
        });
    }
}