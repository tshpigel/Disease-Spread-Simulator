package persistence;

import model.Population;
import model.Rng;
import model.RngDefault;
import model.Disease;
import model.Person;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.stream.Stream;

import org.json.JSONArray;
import org.json.JSONObject;

// represents a JSON Reader that reads the json files and parses them into DSS variables
// citing JsonSerializationDemo
public class JsonReader {
    private String source;
    private final Rng rng = new RngDefault();

    // EFFECTS: constructs the JsonReader to have the source file name
    public JsonReader(String source) {
        this.source = source;
    }

    // EFFECTS: returns a parsed population based on the source file but
    //          throws an IOException if there is an issue in retrieving file data
    public Population readPop() throws IOException {
        return parsePopJson(new JSONObject(readFile()));
    }

    // EFFECTS: returns a parsed disease based on the source file but
    //          throws an IOException if there is an issue in retrieving file data
    public Disease readDis() throws IOException {
        return parseDisJson(new JSONObject(readFile()));
    }

    // EFFECTS: returns a parsed simulation setup based on the source file but
    //          throws an IOException if there is an issue in retrieving file data
    public int[] readSim() throws IOException {
        return parseSimJson(new JSONObject(readFile()));
    }

    // EFFECTS: gets file data as string but throws exception if cannot retrieve file data
    public String readFile() throws IOException {
        StringBuilder sbuild = new StringBuilder();

        try (Stream<String> stream = Files.lines(Paths.get(source), StandardCharsets.UTF_8)) {
            stream.forEach(s -> sbuild.append(s));
        }

        return sbuild.toString();
    }

    // MODIFIES: finalPop
    // EFFECTS: helper for parsePopJson that sets up the population
    public Population setUpPop(JSONArray pop) {
        int length = pop.length();
        int root = (int) Math.sqrt(length);
        Population finalPop = new Population(root, rng, true);
        ArrayList<ArrayList<Person>> people = new ArrayList<ArrayList<Person>>();
        int id = 1;
        for (int i = 0; i < root; i++) {
            ArrayList<Person> row = new ArrayList<Person>();
            for (int j = 0; j < root; j++) {
                JSONObject pobj = pop.getJSONObject(id - 1);
                JSONArray pdata = pobj.getJSONArray(Integer.toString(id));
                Person p = new Person(id, root, pdata.getDouble(0), pdata.getDouble(1), pdata.getDouble(2), 
                        pdata.getBoolean(3), pdata.getBoolean(4), pdata.getBoolean(5), 
                        pdata.getDouble(6), pdata.getDouble(7), new HashSet<Person>(), rng);
                id++;
                row.add(p);
            }
            people.add(row);
        }
        finalPop.setPeople(people);

        return finalPop;
    }

    // MODIFIES: finalPop
    // EFFECTS: parses population from JSON
    public Population parsePopJson(JSONObject json) {
        JSONArray pop = json.getJSONArray("population");
        int length = pop.length();
        Population finalPop = setUpPop(pop);
        
        ArrayList<Person> flattened = finalPop.getPeopleFlat();
        for (int i = 1; i <= length; i++) {
            final int index = i;
            JSONArray friends = pop.getJSONObject(index - 1).getJSONArray(Integer.toString(index)).getJSONArray(8);
            friends.forEach(d -> flattened.get(index - 1).getFriends().add(flattened.get((int) d - 1)));
        }
        return finalPop;
    }

    // EFFECTS: parses disease from JSON
    public Disease parseDisJson(JSONObject json) {
        JSONArray diseaseValues = json.getJSONArray("disease");
        double strength = diseaseValues.getDouble(0);
        double minexp = diseaseValues.getDouble(1);
        double mutatprob = diseaseValues.getDouble(2);
        String transm = diseaseValues.getString(3);
        return new Disease(strength, minexp, mutatprob, transm, rng);
    }

    // EFFECTS: parses the simulation setup from JSON
    public int[] parseSimJson(JSONObject json) {
        JSONArray simValues = json.getJSONArray("simsetup");
        int tick = simValues.getInt(0);
        int duration = simValues.getInt(1);
        int mode = simValues.getInt(2);
        int last = simValues.getInt(3);
        return new int[]{tick, duration, mode, last};
    }
}
